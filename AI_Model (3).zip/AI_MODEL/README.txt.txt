 خطوات تشغيل مشروع Streamlit:

1. وجود Python 3.9 أو أعلى على الجهاز.

2. يكون التيرمنال (Command Prompt) في نفس المجلد اللي فيه الملفات (app.py و requirements.txt).

3. البيئة افتراضية باسم ai_env:

   على Windows:
   python -m venv ai_env_39

4. تفعل البيئة الافتراضية:

   على Windows:
   ai_env_39\Scripts\activate

5. pip install -r requirements.txt

6. تشغيل التطبيق:

   streamlit run app.py

