import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, mean_squared_error, confusion_matrix
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.svm import SVC, SVR
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.linear_model import LinearRegression
from sklearn.cluster import KMeans

st.title("AI Final Project")

file = st.file_uploader("Upload CSV File", type=["csv"])

if file is not None:
    df = pd.read_csv(file)
    st.write("### Data Preview:")
    st.dataframe(df)

    task = st.selectbox("Select Task Type:", ["Classification", "Regression", "Clustering"])

    if task != "Clustering":
        target_column = st.selectbox("Select Target Column:", df.columns)
        X = df.drop(columns=[target_column])
        y = df[target_column]
    else:
        target_column = None
        X = df.copy()
        y = None

    try:
        X = pd.get_dummies(X)
        if y is not None:
            y = pd.to_numeric(y, errors='ignore')
    except:
        st.error("Error in preprocessing the data")

    if task != "Clustering":
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)

    if task == "Clustering":
        k = st.slider("Select number of clusters (K):", 2, 10, 3)

    if task == "Classification":
        classifier_type = st.selectbox("Select Classification Model:", ["KNN", "SVM", "ANN"])

    if st.button("Train Model"):
        if task == "Classification":
            if classifier_type == "KNN":
                model = KNeighborsClassifier()
            elif classifier_type == "SVM":
                model = SVC()
            elif classifier_type == "ANN":
                model = MLPClassifier(max_iter=1000)

            try:
                model.fit(X_train, y_train)
                preds = model.predict(X_test)
                st.success(f"Accuracy: {accuracy_score(y_test, preds):.2f}")
                cm = confusion_matrix(y_test, preds)
                fig, ax = plt.subplots()
                sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax)
                ax.set_xlabel("Predicted")
                ax.set_ylabel("Actual")
                ax.set_title("Confusion Matrix")
                st.pyplot(fig)
            except:
                st.error("Invalid classification data. Please check your target column.")

        elif task == "Regression":
            if y.dtype == 'O':
                st.error("Regression requires numeric target column.")
            else:
                try:
                    model = LinearRegression()
                    model.fit(X_train, y_train)
                    preds = model.predict(X_test)
                    st.success(f"Mean Squared Error: {mean_squared_error(y_test, preds):.2f}")
                    fig1, ax1 = plt.subplots()
                    ax1.scatter(y_test, preds, alpha=0.7)
                    ax1.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--')
                    ax1.set_xlabel("Actual")
                    ax1.set_ylabel("Predicted")
                    ax1.set_title("Actual vs Predicted")
                    st.pyplot(fig1)
                except:
                    st.error("Invalid regression data. Please check your target column.")

        elif task == "Clustering":
            try:
                model = KMeans(n_clusters=k, n_init=10, random_state=42)
                model.fit(X)
                preds = model.labels_
                df["Cluster"] = preds
                st.success("Clustering completed.")
                st.dataframe(df)
                if X.shape[1] >= 2:
                    fig3, ax3 = plt.subplots()
                    ax3.scatter(X.iloc[:, 0], X.iloc[:, 1], c=preds, cmap="viridis")
                    ax3.set_xlabel(X.columns[0])
                    ax3.set_ylabel(X.columns[1])
                    ax3.set_title("Cluster Visualization")
                    st.pyplot(fig3)
                else:
                    st.info("Not enough numeric features to visualize clusters.")
            except:
                st.error("Invalid clustering data.")








